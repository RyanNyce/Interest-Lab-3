//objective of this lab is to create a working interest calculator

#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>

using namespace std;

void wait();

int main()
{
	cout << "<Ryan Nyce> -- Lab <3>" << endl << endl;

	//declared variables
	double netBalance, payment, interestRatePerMonth, averageDailyBalance, interest;
	int d1, d2;
	ifstream in;
	string myData;

	// opening file
	in.open("input.dat");

	in >> netBalance >> payment >> d1 >> d2 >> interestRatePerMonth;

	averageDailyBalance = (netBalance * d1 - payment * d2) / d1;

	interest = averageDailyBalance * interestRatePerMonth;

	//shows user what the interst is in dollars 

	cout << fixed << showpoint << setprecision(2);
	cout << "The interest is $" << interest << endl;
	wait();
	return 0;
	
}

void wait()

{
	if (cin.rdbuf()->in_avail() > 0)
	{
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
	}
	cout << "Press the Enter key to continue ... ";
	cin.get();
}